package com.lookingbus.chaithra.demo;

public interface GoogleMapConstants {

    public String GOOGLE_API_KEY = "AIzaSyCrLVBwzR57uXDgRAelut6xcCBuj10OgnM";
}
