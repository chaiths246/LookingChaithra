package com.lookingbus.chaithra.demo;

import android.os.AsyncTask;
import android.util.Log;

import com.google.transit.realtime.GtfsRealtime;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class VehicalInfo511 extends AsyncTask {

    public static String VEHICLE_MONITORING_API = "http://api.511.org/transit/VehiclePositions?api_key=02a8d971-ff67-4c29-a5f2-a919d16577a7&agency=AC";


    public void getVehicleOnTrip() {
        URL url = null;
        try {
            url = new URL(VEHICLE_MONITORING_API);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        GtfsRealtime.FeedMessage feed = null;
        try {
            feed = GtfsRealtime.FeedMessage.parseFrom(url.openStream());
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(feed != null){
            for (GtfsRealtime.FeedEntity entity : feed.getEntityList()) {
                if (entity.hasVehicle()) {
                    Log.e("VehicalInfo511",entity.getVehicle().toString());
                }
            }
        }
    }

    @Override
    protected Object doInBackground(Object[] objects) {
        getVehicleOnTrip();
        return null;
    }
}
